package com.lagou.edu.annotation;

import java.lang.annotation.*;

/**
 * @author aleng
 * @version 1.0.0
 * @className Service
 * @description TODO
 * @createTime 2020年05月08日 12:59:00
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
public @interface Transactional {}
