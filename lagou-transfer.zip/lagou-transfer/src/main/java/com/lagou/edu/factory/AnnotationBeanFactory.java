package com.lagou.edu.factory;

import cn.hutool.core.util.ClassUtil;
import cn.hutool.core.util.StrUtil;
import com.lagou.edu.annotation.Autowired;
import com.lagou.edu.annotation.Repository;
import com.lagou.edu.annotation.Service;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * @author aleng
 * @version 1.0.0
 * @className AnnotationBeanFactory
 * @description TODO
 * @createTime 2020年05月08日 12:47:00
 */
public class AnnotationBeanFactory {

  private static Map<String, Object> map = new HashMap<>(); // 存储对象
  private static Map<Class<?>, String> classTypeMap = new HashMap<>(); // 存储对象

  static {
    // 扫描所有类
    Set<Class<?>> classes = ClassUtil.scanPackage("com.lagou.edu");
    Set<Class<?>> annotationBeans = new HashSet<>();
    Annotation[] annotations = null;
    Service serviceAnnotation = null;
    Repository repositoryAnnotation = null;
    for (Class<?> tempClass : classes) {
      annotations = tempClass.getAnnotations();
      if (null == annotations || annotations.length == 0) {
        continue;
      }
      for (Annotation annotation : annotations) {
        if (annotation instanceof Service) {
          serviceAnnotation = (Service) annotation;
          String value = serviceAnnotation.value();
          saveBean(value, tempClass);
          annotationBeans.add(tempClass);
        } else if (annotation instanceof Repository) {
          repositoryAnnotation = (Repository) annotation;
          String value = repositoryAnnotation.value();
          // 如果为空则用类名的首字母小写
          saveBean(value, tempClass);
          annotationBeans.add(tempClass);
        }
        continue;
      }
    }
    // bean里面的依赖关系注入
    Object parentBean = null;
    for (Class<?> annotationBean : annotationBeans) {
      Field[] fields = annotationBean.getDeclaredFields();
      Annotation annotation = null;
      Autowired autowired = null;
      String alis = null;
      String parentBeanId = null;
      String beanId = null;
      Object fieldBean = null;
      for (Field field : fields) {
        annotation = field.getAnnotation(Autowired.class);
        if (null == annotation) {
          continue;
        }
        autowired = (Autowired) annotation;
        alis = autowired.value();
        beanId = StrUtil.isEmpty(alis) ? field.getName() : alis;
        fieldBean = map.get(beanId);
        field.setAccessible(true);
        parentBeanId = classTypeMap.get(annotationBean);
        parentBean = map.get(parentBeanId);
        try {
          field.set(parentBean, fieldBean);
          map.put(parentBeanId, parentBean);
        } catch (IllegalAccessException e) {
          e.printStackTrace();
        }
      }
    }
  }

  // 保存bean
  private static void saveBean(String id, Class<?> tempClass) {
    // 如果为空则用类名的首字母小写
    String beanId = StrUtil.isEmpty(id) ? StrUtil.lowerFirst(tempClass.getSimpleName()) : id;
    Object bean = null;
    try {
      bean = tempClass.newInstance();
      map.put(beanId, bean);
      classTypeMap.put(tempClass, beanId);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  // 对外提供获取实例对象的接口（根据id获取）
  public static Object getBean(String id) {
    return map.get(id);
  }
}
