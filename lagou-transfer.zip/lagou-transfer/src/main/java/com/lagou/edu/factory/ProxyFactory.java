package com.lagou.edu.factory;

import com.lagou.edu.annotation.Autowired;
import com.lagou.edu.annotation.Service;
import com.lagou.edu.annotation.Transactional;
import com.lagou.edu.utils.TransactionManager;
import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

/**
 * @author 应癫
 *     <p>代理对象工厂：生成代理对象的
 */
@Service(value = "proxyFactory")
public class ProxyFactory {

  @Autowired(value = "transactionManager")
  private TransactionManager transactionManager;

  //  public void setTransactionManager(TransactionManager transactionManager) {
  //    this.transactionManager = transactionManager;
  //  }

  /*private ProxyFactory(){

  }

  private static ProxyFactory proxyFactory = new ProxyFactory();

  public static ProxyFactory getInstance() {
      return proxyFactory;
  }*/

  /**
   * Jdk动态代理
   *
   * @param obj 委托对象
   * @return 代理对象
   */
  public Object getJdkProxy(Object obj) {

    // 获取代理对象
    return Proxy.newProxyInstance(
        obj.getClass().getClassLoader(),
        obj.getClass().getInterfaces(),
        new InvocationHandler() {
          @Override
          public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            Object result = null;
            boolean ifNeedTransaction = ifNeedTransaction(proxy, method);
            try {
              // 开启事务(关闭事务的自动提交)
              if (ifNeedTransaction) {
                transactionManager.beginTransaction();
              }
              result = method.invoke(obj, args);
              // 提交事务
              if (ifNeedTransaction) {
                transactionManager.commit();
              }
            } catch (Exception e) {
              e.printStackTrace();
              // 回滚事务
              if (ifNeedTransaction) {
                transactionManager.rollback();
              }
              // 抛出异常便于上层servlet捕获
              throw e;
            }
            return result;
          }
        });
  }

  /**
   * 使用cglib动态代理生成代理对象
   *
   * @param obj 委托对象
   * @return
   */
  public Object getCglibProxy(Object obj) {
    return Enhancer.create(
        obj.getClass(),
        new MethodInterceptor() {
          @Override
          public Object intercept(
              Object o, Method method, Object[] objects, MethodProxy methodProxy) throws Throwable {
            Object result = null;
            boolean ifNeedTransaction = ifNeedTransaction(o, method);
            try {
              // 开启事务(关闭事务的自动提交)
              if (ifNeedTransaction) {
                transactionManager.beginTransaction();
              }
              result = method.invoke(obj, objects);
              // 提交事务
              if (ifNeedTransaction) {
                transactionManager.commit();
              }
            } catch (Exception e) {
              e.printStackTrace();
              // 回滚事务
              if (ifNeedTransaction) {
                transactionManager.rollback();
              }
              // 抛出异常便于上层servlet捕获
              throw e;
            }
            return result;
          }
        });
  }

  // 是否需要事务，判断对象是否有加Transactional注解
  private boolean ifNeedTransaction(Object proxy, Method method) {
    Method realMethod = null;
    Object realTarget = null;
    try {
      realTarget = getTarget(proxy);
      realMethod =
          realTarget.getClass().getDeclaredMethod(method.getName(), method.getParameterTypes());
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null != realMethod.getAnnotation(Transactional.class);
  }

  // 根据代理对象回去原对象。
  private Object getTarget(Object proxy) throws Exception {
    Field field = proxy.getClass().getSuperclass().getDeclaredField("h");
    field.setAccessible(true);
    // 获取指定对象中此字段的值
    Object realTarget = field.get(proxy); // 获取Proxy对象中的此字段的值
    Field target = realTarget.getClass().getDeclaredField("val$obj");
    target.setAccessible(true);
    return target.get(realTarget);
  }
}
